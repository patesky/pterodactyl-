# King Installer 👑 — Linux Edition

A professional, modular Linux terminal installer with colored UI, progress bars,
loading animations, automatic dependency detection, OS detection, and full
GitHub-based script delivery.

Supports: **Ubuntu 22/24 · Debian 11/12 · AlmaLinux 9 · Rocky Linux 9**

---

## Quick Start

```bash
# 1. Clone or download
git clone https://github.com/YOU/YOUR-REPO.git
cd KingInstaller-Linux

# 2. Set your GitHub repo in lib/config.sh
nano lib/config.sh

# 3. Run as root
sudo bash king-installer.sh
```

---

## Project Structure

```
KingInstaller-Linux/
│
├── king-installer.sh          ← Launch this (as root)
│
├── lib/
│   ├── config.sh              ← ★ Edit ONLY this to point at your repo
│   ├── ui.sh                  ← Colors, borders, spinners, progress bars
│   ├── logger.sh              ← Timestamped logging to /var/log/king-installer/
│   ├── system.sh              ← OS detection, root check, internet check, deps
│   └── downloader.sh          ← GitHub script downloader (retry, no cache)
│
└── scripts/                   ← Push these to your GitHub repo
    ├── pterodactyl/
    │   ├── install.sh         ← Full guided panel installation
    │   ├── update.sh          ← Backup → download → migrate → restart
    │   └── delete.sh          ← Selective component removal
    └── wings/
        ├── install.sh         ← Docker + Wings + config (2 methods)
        ├── update.sh          ← Stop → download → replace → restart
        └── delete.sh          ← Selective component removal
```

---

## Configuration (lib/config.sh)

This is the **only file you need to edit**:

```bash
GH_USER="YourUsername"
GH_REPO="YourRepository"
GH_BRANCH="main"
```

Everything else — paths, log files, service names — is derived from these
three values and the constants below them.

---

## How It Works

1. **Startup:** `king-installer.sh` sources all `lib/` files, runs a root
   check, internet check, and GitHub reachability check.

2. **Menu selection:** The user picks a module and action (e.g. Pterodactyl →
   Install).

3. **Local first:** If `scripts/pterodactyl/install.sh` exists locally (dev
   mode), it runs that directly.

4. **GitHub download:** In production, the script is downloaded fresh from:
   ```
   https://raw.githubusercontent.com/USER/REPO/main/scripts/pterodactyl/install.sh
   ```
   It retries up to 3 times, checks for empty files, then executes with all
   lib functions available via `export -f`.

5. **Cleanup:** Temp files are deleted on completion or exit.

---

## Feature Reference

| Feature | Detail |
|---|---|
| OS Detection | Ubuntu 22/24, Debian 11/12, AlmaLinux 9, Rocky Linux 9 |
| Root check | Exits with clear message if not root |
| Internet check | Tests Google + GitHub before any download |
| Package detection | `dpkg -s` / `rpm -q` + `command -v` for each dep |
| Auto-install | Missing deps installed silently with spinner |
| Progress bars | `[████░░░░] 60%` — custom bash implementation |
| Spinners | Braille dot spinner (`⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏`) |
| Colors | 12-color ANSI palette with reset, bold, dim |
| Logging | `/var/log/king-installer/install.log` (timestamped) |
| Download retries | Up to 3 attempts with 2s delay between |
| No caching | `Cache-Control: no-cache` + `Pragma: no-cache` headers |
| Crash safety | All menus are loop-based; invalid input silently retries |
| Cleanup | `trap EXIT` removes temp files and restores cursor |
| Secret prompts | `read -rs` for passwords (no echo) |
| Confirm word | Destructive operations require typing `DELETE` |
| Selective delete | Each component removal is individually prompted |
| Summary screen | Full config summary shown before any install begins |
| Modular code | Add a new module by adding a folder to GitHub |

---

## Pterodactyl Panel — What Gets Installed

| Component | Detail |
|---|---|
| Nginx | Web server + vhost config |
| MariaDB | Database server + panel DB + user |
| Redis | Cache + queue backend |
| PHP 8.3 | + all required extensions |
| Composer | PHP dependency manager |
| Node.js 20 | + npm |
| Yarn | Frontend asset manager |
| Panel files | `/var/www/pterodactyl` |
| Queue worker | `pteroq` systemd service |
| Cron job | `php artisan schedule:run` every minute |
| SSL (optional) | Certbot + Let's Encrypt |
| Firewall | UFW or firewall-cmd rules |

---

## Wings — What Gets Installed

| Component | Detail |
|---|---|
| Docker | Official Docker CE via get.docker.com |
| Wings binary | `/usr/local/bin/wings` |
| config.yml | `/etc/pterodactyl/config.yml` |
| Systemd service | `wings.service` |
| Firewall rules | Port 2022 (SFTP) |

**Configuration methods:**
- **Method 1:** Paste the complete `config.yml` from Panel → Admin → Nodes
- **Method 2:** Enter Panel URL + Node UUID + Token ID + Token to auto-generate

---

## Adding a New Module

1. Create a folder in your GitHub repo:
   ```
   scripts/mymodule/
       install.sh
       update.sh
       delete.sh
   ```

2. Each script can use all lib functions (they're exported by `king-installer.sh`).
   Start every script with the standalone sourcing block:
   ```bash
   SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
   _LIB="${SCRIPT_DIR}/../../lib"
   if [[ -f "${_LIB}/ui.sh" ]]; then
       source "${_LIB}/config.sh"
       source "${_LIB}/ui.sh"
       source "${_LIB}/logger.sh"
       source "${_LIB}/system.sh"
   fi
   ```

3. Add a menu section to `king-installer.sh`:
   ```bash
   menu_mymodule() {
       while true; do
           ui::clear; ui::banner
           ui::section "MY MODULE"
           ui::menu_item "1" "Install"
           ui::menu_item "2" "Update"
           ui::menu_item "3" "Delete"
           ui::menu_exit "Back"
           ui::menu_choice CHOICE
           case "$CHOICE" in
               1) _run_module_screen "mymodule/install" ;;
               2) _run_module_screen "mymodule/update"  ;;
               3) _run_module_screen "mymodule/delete"  ;;
               0) return ;;
           esac
       done
   }
   ```

4. Add it to `main_menu`:
   ```bash
   ui::menu_item "3" "My Module"
   # ...
   3) menu_mymodule ;;
   ```

No other files need to change.

---

## Logs

All actions are logged to `/var/log/king-installer/install.log`:

```
[2025-01-15 14:32:01] [INFO ] SESSION START  King Installer v1.0.0
[2025-01-15 14:32:01] [INFO ] Repo: username/repo [main]
[2025-01-15 14:32:05] [OK   ] Internet: reachable
[2025-01-15 14:32:05] [OK   ] GitHub: reachable
[2025-01-15 14:35:12] [----] --- PTERODACTYL PANEL INSTALL ---
[2025-01-15 14:35:12] [INFO ] Domain: panel.example.com  HTTPS: Y  TZ: UTC
[2025-01-15 14:35:14] [OK   ] Installed: nginx
```

---

## Requirements

- Linux (Ubuntu 22/24, Debian 11/12, AlmaLinux 9, Rocky Linux 9)
- Root access (`sudo`)
- `bash` 4.0+
- `curl` (auto-installed if missing)
- Internet connection

---

## License

MIT — use freely, modify freely.
