#!/usr/bin/env bash
# ==============================================================
# scripts/pterodactyl/install.sh
# King Installer — Pterodactyl Panel: Install
# Hosted on GitHub; downloaded and executed by king-installer.sh
# ==============================================================

set -euo pipefail

# ── Source lib if running standalone ──────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
_LIB="${SCRIPT_DIR}/../../lib"
if [[ -f "${_LIB}/ui.sh" ]]; then
    source "${_LIB}/config.sh"
    source "${_LIB}/ui.sh"
    source "${_LIB}/logger.sh"
    source "${_LIB}/system.sh"
fi

# ── Local helpers ─────────────────────────────────────────────
_run() {
    local label="$1"; shift
    ui::spinner_start "$label"
    if "$@" >> "$LOG_FILE" 2>&1; then
        ui::spinner_stop "ok" "$label"
        log::ok "$label"
    else
        ui::spinner_stop "fail" "$label"
        log::error "$label FAILED (cmd: $*)"
        return 1
    fi
}

_run_no_fail() {
    local label="$1"; shift
    ui::spinner_start "$label"
    if "$@" >> "$LOG_FILE" 2>&1; then
        ui::spinner_stop "ok" "$label"
    else
        ui::spinner_stop "warn" "$label"
    fi
}

# ==============================================================
# STEP 0 — Header
# ==============================================================
ui::clear
ui::banner
ui::section "INSTALL PTERODACTYL PANEL"

sys::detect_os
sys::print_os_info

# ==============================================================
# STEP 1 — Dependency Detection
# ==============================================================
ui::subsection "Dependency Check"

NEED_NGINX=false
NEED_MARIADB=false
NEED_REDIS=false
NEED_PHP=false
NEED_COMPOSER=false
NEED_NODE=false
NEED_YARN=false

sys::cmd_exists nginx      && ui::check_item "Nginx"    "ok" || { NEED_NGINX=true;    ui::check_item "Nginx"    "fail"; }
sys::cmd_exists mysqld     && ui::check_item "MariaDB"  "ok" || { NEED_MARIADB=true;  ui::check_item "MariaDB"  "fail"; }
sys::cmd_exists redis-cli  && ui::check_item "Redis"    "ok" || { NEED_REDIS=true;    ui::check_item "Redis"    "fail"; }
sys::cmd_exists php        && ui::check_item "PHP"      "ok" || { NEED_PHP=true;      ui::check_item "PHP"      "fail"; }
sys::cmd_exists composer   && ui::check_item "Composer" "ok" || { NEED_COMPOSER=true; ui::check_item "Composer" "fail"; }
sys::cmd_exists node       && ui::check_item "Node.js"  "ok" || { NEED_NODE=true;     ui::check_item "Node.js"  "fail"; }
sys::cmd_exists yarn       && ui::check_item "Yarn"     "ok" || { NEED_YARN=true;     ui::check_item "Yarn"     "fail"; }

echo

# ==============================================================
# STEP 2 — Gather Configuration
# ==============================================================
ui::subsection "Panel Configuration"

ui::prompt   PANEL_FQDN      "Panel domain (FQDN, e.g. panel.example.com)"
ui::prompt_yn USE_HTTPS      "Enable HTTPS (Let's Encrypt)?" "Y"
if [[ "$USE_HTTPS" == "Y" ]]; then
    ui::prompt LE_EMAIL "Let's Encrypt email address"
fi
ui::prompt_yn SETUP_FIREWALL "Configure firewall automatically?" "Y"
ui::prompt   TIMEZONE        "Timezone" "UTC"
echo
echo -e "  ${DIM}${CYAN}Database password:${RESET}"
ui::menu_item "1" "Generate randomly"
ui::menu_item "2" "Enter custom"
ui::menu_choice _DB_PASS_OPT
if [[ "$_DB_PASS_OPT" == "2" ]]; then
    ui::prompt_secret PANEL_DB_PASS "Database password"
else
    PANEL_DB_PASS=$(sys::gen_password 28)
    ui::ok "Generated password: ${BRIGHT_YELLOW}${PANEL_DB_PASS}${RESET}"
fi

# ── Admin Account ─────────────────────────────────────────────
ui::subsection "Admin Account"

ui::prompt   ADMIN_USERNAME  "Username"
ui::prompt   ADMIN_EMAIL     "Email address"
ui::prompt   ADMIN_FIRSTNAME "First name"
ui::prompt   ADMIN_LASTNAME  "Last name"
ui::prompt_secret ADMIN_PASS "Password"

# ==============================================================
# STEP 3 — Installation Summary
# ==============================================================
ui::subsection "Installation Summary"

echo
ui::summary_row "OS"              "${OS_NAME} ${OS_VERSION}"
ui::summary_row "Panel Domain"    "${PANEL_FQDN}"
ui::summary_row "HTTPS / SSL"     "${USE_HTTPS}"
[[ "$USE_HTTPS" == "Y" ]] && ui::summary_row "LE Email" "${LE_EMAIL}"
ui::summary_row "Firewall"        "${SETUP_FIREWALL}"
ui::summary_row "Timezone"        "${TIMEZONE}"
ui::summary_row "DB Name"         "${PANEL_DB}"
ui::summary_row "DB User"         "${PANEL_DB_USER}"
ui::summary_row "DB Password"     "${PANEL_DB_PASS:0:4}••••••••••••"
echo
ui::summary_row "Admin Username"  "${ADMIN_USERNAME}"
ui::summary_row "Admin Email"     "${ADMIN_EMAIL}"
ui::summary_row "Admin Name"      "${ADMIN_FIRSTNAME} ${ADMIN_LASTNAME}"
echo

ui::prompt_yn _CONFIRM "Proceed with installation?" "Y"
[[ "$_CONFIRM" != "Y" ]] && { ui::warn "Installation cancelled."; exit 0; }

log::section "PTERODACTYL PANEL INSTALL"
log::info "Domain: ${PANEL_FQDN}  HTTPS: ${USE_HTTPS}  TZ: ${TIMEZONE}"

# ==============================================================
# STEP 4 — Install Dependencies
# ==============================================================
ui::subsection "Installing Dependencies"

sys::pkg_update

# ── Nginx ─────────────────────────────────────────────────────
if [[ "$NEED_NGINX" == "true" ]]; then
    case "$OS_ID" in
        ubuntu|debian)
            _run "Installing Nginx" bash -c "$PKG_INSTALL nginx" ;;
        almalinux|rocky)
            _run "Installing Nginx" bash -c "$PKG_INSTALL nginx" ;;
    esac
fi

# ── MariaDB ───────────────────────────────────────────────────
if [[ "$NEED_MARIADB" == "true" ]]; then
    case "$OS_ID" in
        ubuntu|debian)
            _run "Installing MariaDB" bash -c "$PKG_INSTALL mariadb-server" ;;
        almalinux|rocky)
            _run "Installing MariaDB" bash -c "$PKG_INSTALL mariadb-server" ;;
    esac
    _run "Starting MariaDB" systemctl enable --now mariadb
fi

# ── Redis ─────────────────────────────────────────────────────
if [[ "$NEED_REDIS" == "true" ]]; then
    case "$OS_ID" in
        ubuntu|debian)
            _run "Installing Redis" bash -c "$PKG_INSTALL redis-server" ;;
        almalinux|rocky)
            _run "Installing Redis" bash -c "$PKG_INSTALL redis" ;;
    esac
    _run "Starting Redis" systemctl enable --now redis-server 2>/dev/null || \
    _run_no_fail "Starting Redis (alt)" systemctl enable --now redis
fi

# ── PHP 8.3 ───────────────────────────────────────────────────
if [[ "$NEED_PHP" == "true" ]]; then
    case "$OS_ID" in
        ubuntu|debian)
            _run_no_fail "Adding PHP repository" bash -c \
                "apt-get install -yqq software-properties-common lsb-release ca-certificates apt-transport-https && \
                 LC_ALL=C.UTF-8 add-apt-repository -y ppa:ondrej/php && apt-get update -qq"
            _run "Installing PHP 8.3" bash -c "$PKG_INSTALL php8.3 php8.3-{cli,gd,mysql,pdo,mbstring,tokenizer,bcmath,xml,fpm,curl,zip,redis}"
            ;;
        almalinux|rocky)
            _run_no_fail "Adding EPEL + Remi" bash -c \
                "dnf install -y epel-release && \
                 dnf install -y https://rpms.remirepo.net/enterprise/remi-release-9.rpm && \
                 dnf module reset php -y && \
                 dnf module enable php:remi-8.3 -y"
            _run "Installing PHP 8.3" bash -c \
                "$PKG_INSTALL php php-{common,fpm,cli,json,mbstring,bcmath,gd,mysql,pdo,zip,xml,curl,redis}"
            ;;
    esac
fi

# ── Composer ─────────────────────────────────────────────────
if [[ "$NEED_COMPOSER" == "true" ]]; then
    _run "Installing Composer" bash -c \
        "curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer"
fi

# ── Node.js 20 + Yarn ────────────────────────────────────────
if [[ "$NEED_NODE" == "true" ]]; then
    case "$OS_ID" in
        ubuntu|debian)
            _run "Adding NodeJS 20 repo" bash -c \
                "curl -fsSL https://deb.nodesource.com/setup_20.x | bash -"
            _run "Installing NodeJS" bash -c "$PKG_INSTALL nodejs"
            ;;
        almalinux|rocky)
            _run "Adding NodeJS 20 repo" bash -c \
                "curl -fsSL https://rpm.nodesource.com/setup_20.x | bash -"
            _run "Installing NodeJS" bash -c "$PKG_INSTALL nodejs"
            ;;
    esac
fi
if [[ "$NEED_YARN" == "true" ]]; then
    _run "Installing Yarn" bash -c "npm install -g yarn"
fi

# ==============================================================
# STEP 5 — Create Database
# ==============================================================
ui::subsection "Configuring Database"

_run "Starting MariaDB" systemctl start mariadb

mysql -u root <<-MYSQL
    CREATE USER IF NOT EXISTS '${PANEL_DB_USER}'@'127.0.0.1' IDENTIFIED BY '${PANEL_DB_PASS}';
    CREATE DATABASE IF NOT EXISTS ${PANEL_DB};
    GRANT ALL PRIVILEGES ON ${PANEL_DB}.* TO '${PANEL_DB_USER}'@'127.0.0.1' WITH GRANT OPTION;
    FLUSH PRIVILEGES;
MYSQL
ui::status "Database + user created" "ok"
log::ok "Database configured"

# ==============================================================
# STEP 6 — Download Panel
# ==============================================================
ui::subsection "Downloading Pterodactyl Panel"

PANEL_VERSION=$(dl::get_version "pterodactyl/panel" 2>/dev/null || echo "latest")
ui::info "Latest version: ${BRIGHT_YELLOW}${PANEL_VERSION}${RESET}"

mkdir -p "$PANEL_DIR"
cd "$PANEL_DIR"

_run "Downloading panel archive" curl -Lo panel.tar.gz \
    "https://github.com/pterodactyl/panel/releases/latest/download/panel.tar.gz"
_run "Extracting archive" tar -xzf panel.tar.gz
rm -f panel.tar.gz
_run "Setting storage permissions" chmod -R 755 storage/* bootstrap/cache/

# ==============================================================
# STEP 7 — Configure Panel
# ==============================================================
ui::subsection "Configuring Panel"

cp .env.example .env

_run "Installing Composer dependencies" bash -c \
    "COMPOSER_ALLOW_SUPERUSER=1 composer install --no-dev --optimize-autoloader"

_run "Generating application key" php artisan key:generate --force

_run "Configuring environment" php artisan p:environment:setup \
    --author="${LE_EMAIL:-admin@${PANEL_FQDN}}" \
    --url="http${USE_HTTPS/Y/s}://${PANEL_FQDN}" \
    --timezone="${TIMEZONE}" \
    --cache=redis \
    --session=redis \
    --queue=redis \
    --settings-ui=true \
    --telemetry=false \
    --no-interaction

_run "Configuring database connection" php artisan p:environment:database \
    --host=127.0.0.1 \
    --port=3306 \
    --database="${PANEL_DB}" \
    --username="${PANEL_DB_USER}" \
    --password="${PANEL_DB_PASS}" \
    --no-interaction

_run "Running database migrations" php artisan migrate --seed --force

_run "Creating admin account" php artisan p:user:make \
    --email="${ADMIN_EMAIL}" \
    --username="${ADMIN_USERNAME}" \
    --name-first="${ADMIN_FIRSTNAME}" \
    --name-last="${ADMIN_LASTNAME}" \
    --password="${ADMIN_PASS}" \
    --admin=1 \
    --no-interaction

# ==============================================================
# STEP 8 — Set File Permissions
# ==============================================================
ui::subsection "Setting Permissions"

_run "Setting ownership" bash -c \
    "chown -R www-data:www-data ${PANEL_DIR} 2>/dev/null || \
     chown -R nginx:nginx ${PANEL_DIR}"

# ==============================================================
# STEP 9 — Nginx Configuration
# ==============================================================
ui::subsection "Configuring Nginx"

PHP_SOCK=$(ls /var/run/php/php*-fpm.sock 2>/dev/null | head -1 || echo "/var/run/php/php8.3-fpm.sock")

cat > /etc/nginx/sites-available/pterodactyl.conf <<NGINX
server {
    listen 80;
    server_name ${PANEL_FQDN};
    root ${PANEL_DIR}/public;

    index index.php;
    charset utf-8;
    gzip on;
    gzip_types text/plain application/json application/javascript text/css;

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }

    access_log /var/log/nginx/pterodactyl.access.log;
    error_log  /var/log/nginx/pterodactyl.error.log error;

    client_max_body_size 100m;
    client_body_timeout 120s;

    sendfile off;

    location ~ \.php$ {
        fastcgi_split_path_info ^(.+\.php)(/.+)$;
        fastcgi_pass unix:${PHP_SOCK};
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param PHP_VALUE "upload_max_filesize = 100M \n post_max_size=100M";
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_param HTTP_PROXY "";
        fastcgi_intercept_errors off;
        fastcgi_buffer_size 16k;
        fastcgi_buffers 4 16k;
        fastcgi_connect_timeout 300;
        fastcgi_send_timeout 300;
        fastcgi_read_timeout 300;
    }

    location ~ /\.ht { deny all; }
}
NGINX

if [[ -d /etc/nginx/sites-enabled ]]; then
    ln -sf /etc/nginx/sites-available/pterodactyl.conf /etc/nginx/sites-enabled/pterodactyl.conf
    rm -f /etc/nginx/sites-enabled/default
fi

_run "Testing Nginx config" nginx -t
_run "Enabling Nginx"      systemctl enable nginx
_run "Reloading Nginx"     systemctl reload nginx

ui::status "Nginx configured" "ok"

# ── SSL ────────────────────────────────────────────────────────
if [[ "$USE_HTTPS" == "Y" ]]; then
    ui::subsection "Installing SSL Certificate"
    case "$OS_ID" in
        ubuntu|debian)
            _run_no_fail "Installing Certbot" bash -c "$PKG_INSTALL certbot python3-certbot-nginx"
            ;;
        almalinux|rocky)
            _run_no_fail "Installing Certbot" bash -c "$PKG_INSTALL certbot python3-certbot-nginx"
            ;;
    esac
    _run "Obtaining SSL certificate" bash -c \
        "certbot --nginx -d ${PANEL_FQDN} \
         --non-interactive --agree-tos \
         --email ${LE_EMAIL} \
         --redirect"
fi

# ── Firewall ───────────────────────────────────────────────────
if [[ "$SETUP_FIREWALL" == "Y" ]]; then
    ui::subsection "Configuring Firewall"
    if sys::cmd_exists ufw; then
        _run_no_fail "Enabling UFW"     bash -c "ufw --force enable"
        _run_no_fail "Allow SSH"        bash -c "ufw allow 22/tcp"
        _run_no_fail "Allow HTTP"       bash -c "ufw allow 80/tcp"
        _run_no_fail "Allow HTTPS"      bash -c "ufw allow 443/tcp"
        _run_no_fail "Reloading UFW"    bash -c "ufw reload"
    elif sys::cmd_exists firewall-cmd; then
        _run_no_fail "Firewall: SSH"    bash -c "firewall-cmd --permanent --add-service=ssh"
        _run_no_fail "Firewall: HTTP"   bash -c "firewall-cmd --permanent --add-service=http"
        _run_no_fail "Firewall: HTTPS"  bash -c "firewall-cmd --permanent --add-service=https"
        _run_no_fail "Firewall reload"  bash -c "firewall-cmd --reload"
    fi
fi

# ==============================================================
# STEP 10 — Queue Worker (systemd)
# ==============================================================
ui::subsection "Setting Up Queue Worker"

cat > /etc/systemd/system/pteroq.service <<'UNIT'
[Unit]
Description=Pterodactyl Queue Worker
After=redis-server.service mariadb.service

[Service]
User=www-data
Group=www-data
Restart=always
ExecStart=/usr/bin/php /var/www/pterodactyl/artisan queue:work --queue=high,standard,low --sleep=3 --tries=3
StartLimitInterval=180
StartLimitBurst=30
RestartSec=5s

[Install]
WantedBy=multi-user.target
UNIT

_run "Enabling Queue Worker" bash -c "systemctl daemon-reload && systemctl enable --now pteroq"

# ==============================================================
# STEP 11 — Cron Job
# ==============================================================
ui::subsection "Configuring Cron"

(crontab -l 2>/dev/null | grep -v "pterodactyl"; \
 echo "* * * * * php ${PANEL_DIR}/artisan schedule:run >> /dev/null 2>&1") | crontab -
ui::status "Cron job installed" "ok"
log::ok "Cron configured"

# ==============================================================
# STEP 12 — Restart Services & Verify
# ==============================================================
ui::subsection "Restarting Services"

_run_no_fail "Restarting PHP-FPM" bash -c "systemctl restart php8.3-fpm 2>/dev/null || systemctl restart php-fpm"
_run "Restarting Nginx"   systemctl restart nginx
_run "Restarting MariaDB" systemctl restart mariadb
_run "Restarting Redis"   bash -c "systemctl restart redis-server 2>/dev/null || systemctl restart redis"

ui::subsection "Verifying Installation"

VERIFY_OK=true

# Panel files
[[ -f "${PANEL_DIR}/public/index.php" ]] \
    && ui::status "Panel files present"  "ok" \
    || { ui::status "Panel files present" "fail"; VERIFY_OK=false; }

# .env
[[ -f "${PANEL_DIR}/.env" ]] \
    && ui::status ".env configured"     "ok" \
    || { ui::status ".env configured"   "fail"; VERIFY_OK=false; }

# Services running
systemctl is-active --quiet nginx    && ui::status "Nginx running"   "ok" || ui::status "Nginx running"   "warn"
systemctl is-active --quiet mariadb  && ui::status "MariaDB running" "ok" || ui::status "MariaDB running" "warn"
systemctl is-active --quiet pteroq   && ui::status "Queue worker"    "ok" || ui::status "Queue worker"    "warn"

# HTTP check
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost" 2>/dev/null || echo "000")
[[ "$HTTP_CODE" =~ ^[23] ]] \
    && ui::status "HTTP response (${HTTP_CODE})" "ok" \
    || ui::status "HTTP response (${HTTP_CODE} — may need DNS)" "warn"

# ==============================================================
# STEP 13 — Success Report
# ==============================================================
echo
ui::divider
echo
echo -e "  ${BRIGHT_GREEN}${BOLD}${SYM_STAR}  Pterodactyl Panel installed successfully!  ${SYM_STAR}${RESET}"
echo
ui::summary_row "Panel URL"        "http${USE_HTTPS/Y/s}://${PANEL_FQDN}"
ui::summary_row "Admin User"       "${ADMIN_USERNAME}"
ui::summary_row "Admin Email"      "${ADMIN_EMAIL}"
ui::summary_row "DB Password"      "${PANEL_DB_PASS}  ${DIM}(save this!)${RESET}"
ui::summary_row "Log File"         "${LOG_FILE}"
echo
ui::info "Credentials have been logged to: ${LOG_FILE}"
log::info "PANEL URL: http${USE_HTTPS/Y/s}://${PANEL_FQDN}"
log::info "ADMIN USER: ${ADMIN_USERNAME} <${ADMIN_EMAIL}>"
log::info "DB PASS (SENSITIVE): stored in log — protect this file"
echo
