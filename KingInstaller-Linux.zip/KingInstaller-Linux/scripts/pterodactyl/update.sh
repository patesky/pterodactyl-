#!/usr/bin/env bash
# ==============================================================
# scripts/pterodactyl/update.sh
# King Installer — Pterodactyl Panel: Update
# ==============================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
_LIB="${SCRIPT_DIR}/../../lib"
if [[ -f "${_LIB}/ui.sh" ]]; then
    source "${_LIB}/config.sh"
    source "${_LIB}/ui.sh"
    source "${_LIB}/logger.sh"
    source "${_LIB}/system.sh"
fi

_run() {
    local label="$1"; shift
    ui::spinner_start "$label"
    if "$@" >> "$LOG_FILE" 2>&1; then
        ui::spinner_stop "ok" "$label"
        log::ok "$label"
    else
        ui::spinner_stop "fail" "$label"
        log::error "$label — FAILED (cmd: $*)"
        return 1
    fi
}

_run_no_fail() {
    local label="$1"; shift
    ui::spinner_start "$label"
    "$@" >> "$LOG_FILE" 2>&1 && true
    ui::spinner_stop "ok" "$label"
}

# ==============================================================
ui::clear
ui::banner
ui::section "UPDATE PTERODACTYL PANEL"

sys::detect_os

# Pre-flight: panel must exist
if [[ ! -d "$PANEL_DIR" ]]; then
    ui::fail "Panel directory not found: ${PANEL_DIR}"
    ui::warn "Is Pterodactyl Panel installed?"
    exit 1
fi

CURRENT_VER=$(cd "$PANEL_DIR" && php artisan --version 2>/dev/null | grep -oP '[\d.]+' | tail -1 || echo "unknown")
LATEST_VER=$(curl -fsSL --max-time 10 \
    "https://api.github.com/repos/pterodactyl/panel/releases/latest" 2>/dev/null \
    | grep '"tag_name"' | head -1 \
    | sed 's/.*"tag_name": *"\([^"]*\)".*/\1/' || echo "unknown")

ui::info "Current version : ${BRIGHT_YELLOW}${CURRENT_VER}${RESET}"
ui::info "Latest release  : ${BRIGHT_YELLOW}${LATEST_VER}${RESET}"
echo

ui::prompt_yn _CONFIRM "Proceed with update?" "Y"
[[ "$_CONFIRM" != "Y" ]] && { ui::warn "Update cancelled."; exit 0; }

log::section "PTERODACTYL PANEL UPDATE"
cd "$PANEL_DIR"

# ==============================================================
# 1 — Maintenance Mode
# ==============================================================
ui::subsection "Enabling Maintenance Mode"
_run "Maintenance mode ON" php artisan down

# ==============================================================
# 2 — Backup
# ==============================================================
ui::subsection "Creating Backup"

BACKUP_DIR="/var/backups/pterodactyl"
BACKUP_FILE="${BACKUP_DIR}/panel-backup-$(date +%Y%m%d-%H%M%S).tar.gz"
mkdir -p "$BACKUP_DIR"
_run "Backing up panel files" tar -czf "$BACKUP_FILE" \
    --exclude="${PANEL_DIR}/vendor" \
    --exclude="${PANEL_DIR}/node_modules" \
    "$PANEL_DIR"
ui::info "Backup saved to: ${DIM}${BACKUP_FILE}${RESET}"

# Database backup
if sys::cmd_exists mysqldump; then
    DB_BACKUP="${BACKUP_DIR}/panel-db-$(date +%Y%m%d-%H%M%S).sql"
    _run "Backing up database" bash -c \
        "mysqldump ${PANEL_DB} > ${DB_BACKUP}"
    ui::info "Database backup: ${DIM}${DB_BACKUP}${RESET}"
fi

# ==============================================================
# 3 — Download Latest Version
# ==============================================================
ui::subsection "Downloading Latest Panel"

_run "Downloading panel archive" curl -Lo /tmp/panel-latest.tar.gz \
    "https://github.com/pterodactyl/panel/releases/latest/download/panel.tar.gz"
_run "Extracting archive" tar -xzf /tmp/panel-latest.tar.gz
rm -f /tmp/panel-latest.tar.gz

# ==============================================================
# 4 — Update Composer Dependencies
# ==============================================================
ui::subsection "Updating Composer Dependencies"

_run "Updating Composer packages" bash -c \
    "COMPOSER_ALLOW_SUPERUSER=1 composer install --no-dev --optimize-autoloader"

# ==============================================================
# 5 — Database Migrations
# ==============================================================
ui::subsection "Running Database Migrations"

_run "Running migrations" php artisan migrate --force
_run "Seeding database"   php artisan db:seed --force 2>/dev/null || true

# ==============================================================
# 6 — Clear Cache & Re-optimize
# ==============================================================
ui::subsection "Clearing Cache"

_run "Clearing view cache"   php artisan view:clear
_run "Clearing config cache" php artisan config:clear
_run "Clearing route cache"  php artisan route:clear
_run "Clearing event cache"  php artisan event:clear
_run "Clearing compiled"     php artisan clear-compiled
_run "Caching config"        php artisan config:cache
_run "Caching routes"        php artisan route:cache
_run "Caching views"         php artisan view:cache

# ==============================================================
# 7 — Re-set Permissions
# ==============================================================
ui::subsection "Setting Permissions"

_run "Setting ownership" bash -c \
    "chown -R www-data:www-data ${PANEL_DIR} 2>/dev/null || \
     chown -R nginx:nginx ${PANEL_DIR}"
_run "Setting storage permissions" chmod -R 755 "${PANEL_DIR}/storage"/* \
    "${PANEL_DIR}/bootstrap/cache/"

# ==============================================================
# 8 — Restart Services
# ==============================================================
ui::subsection "Restarting Services"

_run_no_fail "Restarting PHP-FPM" bash -c \
    "systemctl restart php8.3-fpm 2>/dev/null || systemctl restart php-fpm"
_run "Restarting Queue Worker"    systemctl restart pteroq
_run "Reloading Nginx"            systemctl reload nginx

# ==============================================================
# 9 — Disable Maintenance Mode
# ==============================================================
ui::subsection "Disabling Maintenance Mode"
_run "Maintenance mode OFF" php artisan up

# ==============================================================
# 10 — Verify
# ==============================================================
ui::subsection "Verifying Update"

NEW_VER=$(php artisan --version 2>/dev/null | grep -oP '[\d.]+' | tail -1 || echo "unknown")
ui::summary_row "Previous version" "${CURRENT_VER}"
ui::summary_row "Updated version"  "${NEW_VER}"
ui::summary_row "Backup location"  "${BACKUP_FILE}"

systemctl is-active --quiet nginx   && ui::status "Nginx running"        "ok" || ui::status "Nginx running"        "warn"
systemctl is-active --quiet pteroq  && ui::status "Queue worker running" "ok" || ui::status "Queue worker running" "warn"

echo
ui::ok "${BOLD}Pterodactyl Panel updated successfully!${RESET}"
log::ok "Panel updated: ${CURRENT_VER} → ${NEW_VER}"
echo
