#!/usr/bin/env bash
# ==============================================================
# scripts/pterodactyl/delete.sh
# King Installer — Pterodactyl Panel: Delete
# ==============================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
_LIB="${SCRIPT_DIR}/../../lib"
if [[ -f "${_LIB}/ui.sh" ]]; then
    source "${_LIB}/config.sh"
    source "${_LIB}/ui.sh"
    source "${_LIB}/logger.sh"
    source "${_LIB}/system.sh"
fi

_rm() {
    local label="$1"; shift
    ui::spinner_start "Removing: $label"
    "$@" >> "$LOG_FILE" 2>&1 && true
    ui::spinner_stop "ok" "Removed: $label"
    log::ok "Removed: $label"
}

# ==============================================================
ui::clear
ui::banner
ui::section "DELETE PTERODACTYL PANEL"

sys::detect_os

echo -e "  ${BRIGHT_RED}${BOLD}WARNING: This will permanently remove Pterodactyl Panel!${RESET}"
echo -e "  ${DIM}This operation cannot be undone.${RESET}"
echo

if ! ui::confirm_word "DELETE"; then
    echo
    ui::warn "Confirmation not matched. Operation cancelled."
    exit 0
fi

# ==============================================================
# Select what to remove
# ==============================================================
ui::subsection "Select Components to Remove"

echo -e "  ${DIM}Press${RESET} ${BRIGHT_GREEN}Y${RESET} ${DIM}to remove, ${RESET}${RED}N${RESET} ${DIM}to keep each component:${RESET}"
echo

ui::prompt_yn RM_FILES    "Remove panel files (${PANEL_DIR})?" "Y"
ui::prompt_yn RM_DATABASE "Remove database and DB user?"       "Y"
ui::prompt_yn RM_REDIS    "Remove Redis configuration?"        "N"
ui::prompt_yn RM_NGINX    "Remove Nginx configuration?"        "Y"
ui::prompt_yn RM_SSL      "Remove SSL certificates?"           "Y"
ui::prompt_yn RM_CRON     "Remove cron job?"                   "Y"
ui::prompt_yn RM_QUEUE    "Remove queue worker service?"       "Y"
ui::prompt_yn RM_USER     "Remove www-data system user?"       "N"

echo
ui::subsection "Removal Summary"
[[ "$RM_FILES"    == "Y" ]] && ui::bullet "Panel files:     ${PANEL_DIR}"
[[ "$RM_DATABASE" == "Y" ]] && ui::bullet "Database:        ${PANEL_DB}  (user: ${PANEL_DB_USER})"
[[ "$RM_REDIS"    == "Y" ]] && ui::bullet "Redis config"
[[ "$RM_NGINX"    == "Y" ]] && ui::bullet "Nginx site config"
[[ "$RM_SSL"      == "Y" ]] && ui::bullet "SSL certificates"
[[ "$RM_CRON"     == "Y" ]] && ui::bullet "Cron job"
[[ "$RM_QUEUE"    == "Y" ]] && ui::bullet "Queue worker service (pteroq)"
[[ "$RM_USER"     == "Y" ]] && ui::bullet "System user (www-data)"
echo

ui::prompt_yn _FINAL_CONFIRM "Are you absolutely sure? This is your last chance." "N"
[[ "$_FINAL_CONFIRM" != "Y" ]] && { ui::warn "Cancelled."; exit 0; }

log::section "PTERODACTYL PANEL DELETE"

# ==============================================================
# 1 — Stop services
# ==============================================================
ui::subsection "Stopping Services"

ui::spinner_start "Stopping Queue Worker"
systemctl stop pteroq  2>/dev/null || true
systemctl disable pteroq 2>/dev/null || true
ui::spinner_stop "ok" "Queue Worker stopped"

ui::spinner_start "Stopping Nginx"
systemctl stop nginx 2>/dev/null || true
ui::spinner_stop "ok" "Nginx stopped"

# ==============================================================
# 2 — Remove Cron
# ==============================================================
if [[ "$RM_CRON" == "Y" ]]; then
    ui::subsection "Removing Cron Job"
    (crontab -l 2>/dev/null | grep -v "pterodactyl") | crontab - 2>/dev/null || true
    ui::status "Cron job removed" "ok"
    log::ok "Cron removed"
fi

# ==============================================================
# 3 — Remove Queue Worker Service
# ==============================================================
if [[ "$RM_QUEUE" == "Y" ]]; then
    ui::subsection "Removing Queue Worker"
    _rm "pteroq service file" rm -f /etc/systemd/system/pteroq.service
    systemctl daemon-reload 2>/dev/null || true
fi

# ==============================================================
# 4 — Remove SSL Certificates
# ==============================================================
if [[ "$RM_SSL" == "Y" ]]; then
    ui::subsection "Removing SSL Certificates"
    if command -v certbot > /dev/null 2>&1; then
        # Try to find and revoke; non-fatal
        ui::spinner_start "Removing Certbot certificates"
        certbot delete --non-interactive 2>/dev/null || true
        ui::spinner_stop "ok" "SSL certificates removed"
        log::ok "SSL certs removed"
    else
        ui::status "Certbot not installed — skipping" "skip"
    fi
fi

# ==============================================================
# 5 — Remove Nginx Config
# ==============================================================
if [[ "$RM_NGINX" == "Y" ]]; then
    ui::subsection "Removing Nginx Configuration"
    _rm "Nginx site (sites-enabled)"    rm -f /etc/nginx/sites-enabled/pterodactyl.conf
    _rm "Nginx site (sites-available)"  rm -f /etc/nginx/sites-available/pterodactyl.conf
    ui::spinner_start "Reloading Nginx"
    systemctl reload nginx 2>/dev/null || true
    ui::spinner_stop "ok" "Nginx reloaded"
fi

# ==============================================================
# 6 — Remove Database
# ==============================================================
if [[ "$RM_DATABASE" == "Y" ]]; then
    ui::subsection "Removing Database"
    mysql -u root 2>/dev/null <<-MYSQL || ui::warn "MySQL commands had errors — database may already be removed."
        DROP DATABASE IF EXISTS ${PANEL_DB};
        DROP USER IF EXISTS '${PANEL_DB_USER}'@'127.0.0.1';
        FLUSH PRIVILEGES;
MYSQL
    ui::status "Database + user removed" "ok"
    log::ok "DB removed: ${PANEL_DB}"
fi

# ==============================================================
# 7 — Remove Redis Config
# ==============================================================
if [[ "$RM_REDIS" == "Y" ]]; then
    ui::subsection "Removing Redis Configuration"
    ui::spinner_start "Flushing Redis database"
    redis-cli FLUSHALL 2>/dev/null || true
    ui::spinner_stop "ok" "Redis flushed"
    log::ok "Redis flushed"
fi

# ==============================================================
# 8 — Remove Panel Files
# ==============================================================
if [[ "$RM_FILES" == "Y" ]]; then
    ui::subsection "Removing Panel Files"
    _rm "Panel directory" rm -rf "$PANEL_DIR"
fi

# ==============================================================
# 9 — Remove System User
# ==============================================================
if [[ "$RM_USER" == "Y" ]]; then
    ui::subsection "Removing System User"
    ui::spinner_start "Removing www-data user"
    userdel -r www-data 2>/dev/null || true
    ui::spinner_stop "ok" "User removed"
    log::ok "User www-data removed"
fi

# ==============================================================
# Done
# ==============================================================
echo
ui::divider
echo
ui::ok "${BOLD}Pterodactyl Panel has been removed.${RESET}"
log::ok "Pterodactyl Panel removal complete."
echo
