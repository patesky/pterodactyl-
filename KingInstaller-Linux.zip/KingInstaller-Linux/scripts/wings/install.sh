#!/usr/bin/env bash
# ==============================================================
# scripts/wings/install.sh
# King Installer — Wings: Install
# ==============================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
_LIB="${SCRIPT_DIR}/../../lib"
if [[ -f "${_LIB}/ui.sh" ]]; then
    source "${_LIB}/config.sh"
    source "${_LIB}/ui.sh"
    source "${_LIB}/logger.sh"
    source "${_LIB}/system.sh"
fi

_run() {
    local label="$1"; shift
    ui::spinner_start "$label"
    if "$@" >> "$LOG_FILE" 2>&1; then
        ui::spinner_stop "ok" "$label"
        log::ok "$label"
    else
        ui::spinner_stop "fail" "$label"
        log::error "$label — FAILED (cmd: $*)"
        return 1
    fi
}

_run_no_fail() {
    local label="$1"; shift
    ui::spinner_start "$label"
    "$@" >> "$LOG_FILE" 2>&1 && true
    ui::spinner_stop "ok" "$label"
}

# ==============================================================
ui::clear
ui::banner
ui::section "INSTALL WINGS"

sys::detect_os
sys::print_os_info

# ==============================================================
# STEP 1 — Dependency Check
# ==============================================================
ui::subsection "Dependency Check"

NEED_DOCKER=false
NEED_CURL=false
NEED_TAR=false

sys::cmd_exists docker && ui::check_item "Docker"        "ok" || { NEED_DOCKER=true; ui::check_item "Docker"    "fail"; }
sys::cmd_exists curl   && ui::check_item "curl"          "ok" || { NEED_CURL=true;   ui::check_item "curl"      "fail"; }
sys::cmd_exists tar    && ui::check_item "tar"           "ok" || { NEED_TAR=true;    ui::check_item "tar"       "fail"; }
                          ui::check_item "Wings binary"  "fail"
echo

# ==============================================================
# STEP 2 — Install Dependencies
# ==============================================================
ui::subsection "Installing Required Packages"

sys::pkg_update

if [[ "$NEED_CURL" == "true" ]]; then
    _run "Installing curl" bash -c "$PKG_INSTALL curl"
fi
if [[ "$NEED_TAR" == "true" ]]; then
    _run "Installing tar"  bash -c "$PKG_INSTALL tar"
fi

# ── Docker ────────────────────────────────────────────────────
if [[ "$NEED_DOCKER" == "true" ]]; then
    ui::subsection "Installing Docker"
    _run "Installing Docker (official script)" bash -c \
        "curl -sSL https://get.docker.com/ | CHANNEL=stable bash"
    _run "Enabling Docker service" systemctl enable --now docker
    ui::status "Docker installed" "ok"
    log::ok "Docker installed"
else
    ui::info "Docker already installed — ensuring service is running..."
    _run_no_fail "Starting Docker" systemctl enable --now docker
fi

# ── Firewall rules ────────────────────────────────────────────
ui::subsection "Configuring Firewall Rules"

if sys::cmd_exists ufw; then
    _run_no_fail "UFW: allow SSH"          bash -c "ufw allow 22/tcp"
    _run_no_fail "UFW: allow Wings (2022)" bash -c "ufw allow 2022/tcp"
    _run_no_fail "UFW: allow SFTP (2022)"  bash -c "ufw allow 2022/tcp"
    _run_no_fail "UFW: reload"             bash -c "ufw --force enable && ufw reload"
elif sys::cmd_exists firewall-cmd; then
    _run_no_fail "Firewall: SSH"           bash -c "firewall-cmd --permanent --add-service=ssh"
    _run_no_fail "Firewall: Wings port"    bash -c "firewall-cmd --permanent --add-port=2022/tcp"
    _run_no_fail "Firewall: reload"        bash -c "firewall-cmd --reload"
fi

# ==============================================================
# STEP 3 — Download Wings Binary
# ==============================================================
ui::subsection "Downloading Wings"

WINGS_VERSION=$(curl -fsSL --max-time 10 \
    "https://api.github.com/repos/pterodactyl/wings/releases/latest" 2>/dev/null \
    | grep '"tag_name"' | head -1 \
    | sed 's/.*"tag_name": *"\([^"]*\)".*/\1/' || echo "latest")

ARCH=$(uname -m)
case "$ARCH" in
    x86_64)  WINGS_ARCH="amd64" ;;
    aarch64) WINGS_ARCH="arm64" ;;
    armv7l)  WINGS_ARCH="arm"   ;;
    *)       WINGS_ARCH="amd64" ;;
esac

ui::info "Wings version : ${BRIGHT_YELLOW}${WINGS_VERSION}${RESET}"
ui::info "Architecture  : ${BRIGHT_YELLOW}${ARCH} → ${WINGS_ARCH}${RESET}"
echo

mkdir -p "$WINGS_DIR"

_run "Downloading Wings binary" curl -fsSL -o "$WINGS_BIN" \
    "https://github.com/pterodactyl/wings/releases/latest/download/wings_linux_${WINGS_ARCH}"
_run "Setting binary permissions" chmod u+x "$WINGS_BIN"

# ==============================================================
# STEP 4 — Configure Wings
# ==============================================================
ui::subsection "Wings Configuration"

echo -e "  ${BRIGHT_WHITE}${BOLD}Choose configuration method:${RESET}"
echo
ui::menu_item "1" "Paste config.yml from Panel Admin → Nodes → Configuration"
ui::menu_item "2" "Enter Panel URL + Node UUID + Token (auto-generate config)"
ui::menu_exit "Back"
echo

ui::menu_choice CONFIG_METHOD

case "$CONFIG_METHOD" in
    # ----------------------------------------------------------
    "1")
        ui::subsection "Paste config.yml"
        echo -e "  ${DIM}Go to your Panel:${RESET}"
        echo -e "  ${CYAN}Admin Area${RESET} ${DIM}›${RESET} ${CYAN}Nodes${RESET} ${DIM}›${RESET} ${CYAN}Your Node${RESET} ${DIM}›${RESET} ${CYAN}Configuration${RESET}"
        echo
        echo -e "  ${DIM}Paste the entire config.yml content below.${RESET}"
        echo -e "  ${DIM}Press ${BRIGHT_WHITE}Ctrl+D${RESET}${DIM} on a new line when done.${RESET}"
        echo
        ui::divider

        CONFIG_CONTENT=$(cat)

        ui::divider
        echo

        if [[ -z "$CONFIG_CONTENT" ]]; then
            ui::fail "No content pasted. Aborting."
            exit 1
        fi

        mkdir -p "$WINGS_DIR"
        echo "$CONFIG_CONTENT" > "${WINGS_DIR}/config.yml"
        ui::status "config.yml saved" "ok"
        log::ok "config.yml saved from paste"

        # Basic YAML validation
        if command -v python3 > /dev/null 2>&1; then
            ui::spinner_start "Validating YAML..."
            if python3 -c "import yaml; yaml.safe_load(open('${WINGS_DIR}/config.yml'))" >> "$LOG_FILE" 2>&1; then
                ui::spinner_stop "ok" "YAML validation passed"
                log::ok "YAML valid"
            else
                ui::spinner_stop "warn" "YAML validation warning (continuing)"
                log::warn "YAML validation failed — user may need to check config"
            fi
        fi
        ;;

    # ----------------------------------------------------------
    "2")
        ui::subsection "Auto-Generate config.yml"

        ui::prompt WINGS_PANEL_URL  "Panel URL (e.g. https://panel.example.com)"
        ui::prompt WINGS_NODE_UUID  "Node UUID"
        ui::prompt WINGS_TOKEN_ID   "Token ID"
        ui::prompt WINGS_TOKEN      "Token"

        # Strip trailing slash
        WINGS_PANEL_URL="${WINGS_PANEL_URL%/}"

        ui::spinner_start "Generating config.yml..."

        mkdir -p "$WINGS_DIR"
        mkdir -p /var/lib/pterodactyl/volumes
        mkdir -p /var/log/pterodactyl

        cat > "${WINGS_DIR}/config.yml" <<YAML
debug: false
uuid: ${WINGS_NODE_UUID}
token_id: ${WINGS_TOKEN_ID}
token: ${WINGS_TOKEN}
api:
  host: 0.0.0.0
  port: 8080
  ssl:
    enabled: false
    cert: /etc/letsencrypt/live/node.example.com/fullchain.pem
    key:  /etc/letsencrypt/live/node.example.com/privkey.pem
  upload_limit: 100
system:
  data: /var/lib/pterodactyl/volumes
  sftp:
    bind_port: 2022
remote: ${WINGS_PANEL_URL}
allowed_mounts: []
remote_query:
  timeout: 30
  boot_servers_per_page: 50
YAML

        ui::spinner_stop "ok" "config.yml generated"
        log::ok "config.yml generated from token inputs"

        ui::info "Config written to: ${DIM}${WINGS_DIR}/config.yml${RESET}"
        ;;

    "0")
        ui::warn "Going back."
        exit 0
        ;;

    *)
        ui::fail "Invalid option."
        exit 1
        ;;
esac

# ==============================================================
# STEP 5 — Install Wings systemd Service
# ==============================================================
ui::subsection "Installing Wings Service"

cat > "$WINGS_SERVICE" <<'UNIT'
[Unit]
Description=Pterodactyl Wings Daemon
After=docker.service
Requires=docker.service
PartOf=docker.service

[Service]
User=root
WorkingDirectory=/etc/pterodactyl
LimitNOFILE=4096
PIDFile=/var/run/wings/daemon.pid
ExecStart=/usr/local/bin/wings
Restart=on-failure
StartLimitInterval=180
StartLimitBurst=30
RestartSec=5s

[Install]
WantedBy=multi-user.target
UNIT

_run "Reloading systemd"       systemctl daemon-reload
_run "Enabling Wings service"  systemctl enable wings
_run "Starting Wings service"  systemctl start wings

# ==============================================================
# STEP 6 — Verify
# ==============================================================
ui::subsection "Verifying Wings"

sleep 3   # Give Wings a moment to start

systemctl is-active --quiet wings \
    && ui::status "Wings service running"    "ok" \
    || ui::status "Wings service (check log)" "warn"

[[ -f "$WINGS_BIN" ]] \
    && ui::status "Wings binary present"    "ok" \
    || ui::status "Wings binary missing"    "fail"

[[ -f "${WINGS_DIR}/config.yml" ]] \
    && ui::status "config.yml present"      "ok" \
    || ui::status "config.yml missing"      "fail"

systemctl is-active --quiet docker \
    && ui::status "Docker running"          "ok" \
    || ui::status "Docker not running"      "warn"

# Panel connectivity check
if [[ -n "${WINGS_PANEL_URL:-}" ]]; then
    ui::spinner_start "Testing Panel connection..."
    if curl -sf --max-time 8 "${WINGS_PANEL_URL}" > /dev/null 2>&1; then
        ui::spinner_stop "ok" "Panel reachable"
        log::ok "Panel reachable: ${WINGS_PANEL_URL}"
    else
        ui::spinner_stop "warn" "Panel not reachable — check URL and firewall"
        log::warn "Panel unreachable: ${WINGS_PANEL_URL}"
    fi
fi

# ==============================================================
# Done
# ==============================================================
echo
ui::divider
echo
echo -e "  ${BRIGHT_GREEN}${BOLD}${SYM_STAR}  Wings installed successfully!  ${SYM_STAR}${RESET}"
echo
ui::summary_row "Wings binary"    "$WINGS_BIN"
ui::summary_row "Config file"     "${WINGS_DIR}/config.yml"
ui::summary_row "Service name"    "wings"
ui::summary_row "Log file"        "${LOG_FILE}"
echo
ui::info "Check Wings logs with: ${BRIGHT_YELLOW}journalctl -u wings -f${RESET}"
ui::info "In Panel: Admin → Nodes → Your Node → verify status is ${BRIGHT_GREEN}Online${RESET}"
log::ok "Wings installation complete."
echo
