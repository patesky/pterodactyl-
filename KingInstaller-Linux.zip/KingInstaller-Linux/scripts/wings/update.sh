#!/usr/bin/env bash
# ==============================================================
# scripts/wings/update.sh
# King Installer — Wings: Update
# ==============================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
_LIB="${SCRIPT_DIR}/../../lib"
if [[ -f "${_LIB}/ui.sh" ]]; then
    source "${_LIB}/config.sh"
    source "${_LIB}/ui.sh"
    source "${_LIB}/logger.sh"
    source "${_LIB}/system.sh"
fi

_run() {
    local label="$1"; shift
    ui::spinner_start "$label"
    if "$@" >> "$LOG_FILE" 2>&1; then
        ui::spinner_stop "ok" "$label"
        log::ok "$label"
    else
        ui::spinner_stop "fail" "$label"
        log::error "$label — FAILED"
        return 1
    fi
}

# ==============================================================
ui::clear
ui::banner
ui::section "UPDATE WINGS"

sys::detect_os

# Pre-flight checks
if [[ ! -f "$WINGS_BIN" ]]; then
    ui::fail "Wings binary not found at ${WINGS_BIN}."
    ui::warn "Is Wings installed?"
    exit 1
fi

# Current version
CURRENT_VER=$("$WINGS_BIN" --version 2>/dev/null | grep -oP '[\d.]+' | head -1 || echo "unknown")
LATEST_VER=$(curl -fsSL --max-time 10 \
    "https://api.github.com/repos/pterodactyl/wings/releases/latest" 2>/dev/null \
    | grep '"tag_name"' | head -1 \
    | sed 's/.*"tag_name": *"\([^"]*\)".*/\1/' || echo "unknown")

ui::info "Current version : ${BRIGHT_YELLOW}${CURRENT_VER}${RESET}"
ui::info "Latest release  : ${BRIGHT_YELLOW}${LATEST_VER}${RESET}"
echo

if [[ "$CURRENT_VER" == "$LATEST_VER" ]]; then
    ui::ok "Wings is already up to date."
    ui::prompt_yn _FORCE "Force re-download anyway?" "N"
    [[ "$_FORCE" != "Y" ]] && exit 0
fi

ui::prompt_yn _CONFIRM "Proceed with update?" "Y"
[[ "$_CONFIRM" != "Y" ]] && { ui::warn "Update cancelled."; exit 0; }

log::section "WINGS UPDATE"

# ==============================================================
# 1 — Stop Wings
# ==============================================================
ui::subsection "Stopping Wings"
_run "Stopping Wings service" systemctl stop wings
ui::status "Wings stopped" "ok"

# ==============================================================
# 2 — Backup current binary
# ==============================================================
ui::subsection "Backing Up Current Binary"

BACKUP_BIN="${WINGS_BIN}.bak.$(date +%Y%m%d%H%M%S)"
_run "Backing up binary" cp "$WINGS_BIN" "$BACKUP_BIN"
ui::info "Backup: ${DIM}${BACKUP_BIN}${RESET}"

# ==============================================================
# 3 — Download latest Wings
# ==============================================================
ui::subsection "Downloading Latest Wings"

ARCH=$(uname -m)
case "$ARCH" in
    x86_64)  WINGS_ARCH="amd64" ;;
    aarch64) WINGS_ARCH="arm64" ;;
    armv7l)  WINGS_ARCH="arm"   ;;
    *)       WINGS_ARCH="amd64" ;;
esac

ui::info "Architecture: ${BRIGHT_YELLOW}${ARCH} → ${WINGS_ARCH}${RESET}"

_run "Downloading Wings binary" curl -fsSL -o "$WINGS_BIN" \
    "https://github.com/pterodactyl/wings/releases/latest/download/wings_linux_${WINGS_ARCH}"
_run "Setting binary permissions" chmod u+x "$WINGS_BIN"

# ==============================================================
# 4 — Verify config.yml is intact
# ==============================================================
ui::subsection "Verifying Configuration"

if [[ -f "${WINGS_DIR}/config.yml" ]]; then
    ui::status "config.yml intact — not modified" "ok"
    log::ok "config.yml preserved"
else
    ui::status "config.yml not found — Wings may not start correctly" "warn"
    log::warn "config.yml missing after update"
fi

# ==============================================================
# 5 — Restart Wings
# ==============================================================
ui::subsection "Restarting Wings"

_run "Starting Wings service" systemctl start wings
sleep 3

# ==============================================================
# 6 — Verify
# ==============================================================
ui::subsection "Verifying Update"

NEW_VER=$("$WINGS_BIN" --version 2>/dev/null | grep -oP '[\d.]+' | head -1 || echo "unknown")

systemctl is-active --quiet wings \
    && ui::status "Wings service running"    "ok" \
    || ui::status "Wings service not running — check logs" "fail"

ui::summary_row "Previous version" "${CURRENT_VER}"
ui::summary_row "Updated version"  "${NEW_VER}"
ui::summary_row "Binary backup"    "${BACKUP_BIN}"
ui::summary_row "Config file"      "${WINGS_DIR}/config.yml  (preserved)"

echo
ui::info "Check logs: ${BRIGHT_YELLOW}journalctl -u wings -f${RESET}"
echo
ui::ok "${BOLD}Wings updated successfully!${RESET}"
log::ok "Wings updated: ${CURRENT_VER} → ${NEW_VER}"
echo
