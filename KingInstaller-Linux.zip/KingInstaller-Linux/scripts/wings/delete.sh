#!/usr/bin/env bash
# ==============================================================
# scripts/wings/delete.sh
# King Installer — Wings: Delete
# ==============================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
_LIB="${SCRIPT_DIR}/../../lib"
if [[ -f "${_LIB}/ui.sh" ]]; then
    source "${_LIB}/config.sh"
    source "${_LIB}/ui.sh"
    source "${_LIB}/logger.sh"
    source "${_LIB}/system.sh"
fi

_rm() {
    local label="$1"; shift
    ui::spinner_start "Removing: $label"
    "$@" >> "$LOG_FILE" 2>&1 && true
    ui::spinner_stop "ok" "Removed: $label"
    log::ok "Removed: $label"
}

# ==============================================================
ui::clear
ui::banner
ui::section "DELETE WINGS"

sys::detect_os

echo -e "  ${BRIGHT_RED}${BOLD}WARNING: This will permanently remove Wings!${RESET}"
echo -e "  ${DIM}Running servers will be stopped. This cannot be undone.${RESET}"
echo

ui::prompt_yn _CONFIRM "Are you sure you want to remove Wings?" "N"
[[ "$_CONFIRM" != "Y" ]] && { ui::warn "Cancelled."; exit 0; }

# ==============================================================
# Select what to remove
# ==============================================================
ui::subsection "Select Components to Remove"

echo -e "  ${DIM}Press${RESET} ${BRIGHT_GREEN}Y${RESET} ${DIM}to remove, ${RESET}${RED}N${RESET} ${DIM}to keep:${RESET}"
echo

ui::prompt_yn RM_BINARY     "Remove Wings binary (${WINGS_BIN})?"        "Y"
ui::prompt_yn RM_CONFIG     "Remove Wings config.yml?"                    "Y"
ui::prompt_yn RM_SERVICE    "Remove Wings systemd service?"               "Y"
ui::prompt_yn RM_DOCKER     "Remove Docker (engine + CLI)?"               "N"
ui::prompt_yn RM_DOCKER_IMG "Remove all Docker images?"                   "N"
ui::prompt_yn RM_DOCKER_CTR "Remove all Docker containers?"               "N"
ui::prompt_yn RM_DOCKER_VOL "Remove all Docker volumes (server data!)?"   "N"

echo
ui::subsection "Removal Summary"
[[ "$RM_BINARY"     == "Y" ]] && ui::bullet "Wings binary:     ${WINGS_BIN}"
[[ "$RM_CONFIG"     == "Y" ]] && ui::bullet "config.yml:       ${WINGS_DIR}/config.yml"
[[ "$RM_SERVICE"    == "Y" ]] && ui::bullet "Systemd service:  wings.service"
[[ "$RM_DOCKER"     == "Y" ]] && ui::bullet "Docker engine + CLI"
[[ "$RM_DOCKER_IMG" == "Y" ]] && ui::bullet "All Docker images"
[[ "$RM_DOCKER_CTR" == "Y" ]] && ui::bullet "All Docker containers"
[[ "$RM_DOCKER_VOL" == "Y" ]] && { echo
    echo -e "  ${BRIGHT_RED}${BOLD}  ⚠  WARNING: Removing Docker volumes will DELETE all server data!${RESET}"; echo; }

echo
ui::prompt_yn _FINAL "Confirm removal of selected components?" "N"
[[ "$_FINAL" != "Y" ]] && { ui::warn "Cancelled."; exit 0; }

log::section "WINGS DELETE"

# ==============================================================
# 1 — Stop + Disable Wings service
# ==============================================================
ui::subsection "Stopping Wings"

ui::spinner_start "Stopping Wings service"
systemctl stop wings   2>/dev/null || true
systemctl disable wings 2>/dev/null || true
ui::spinner_stop "ok" "Wings service stopped"
log::ok "Wings stopped"

# ==============================================================
# 2 — Docker cleanup (before removing engine)
# ==============================================================
if [[ "$RM_DOCKER_CTR" == "Y" ]]; then
    ui::subsection "Removing Docker Containers"
    ui::spinner_start "Stopping all containers"
    docker stop  $(docker ps -aq) 2>/dev/null || true
    ui::spinner_stop "ok" "Containers stopped"
    _rm "All Docker containers" bash -c "docker rm -f $(docker ps -aq) 2>/dev/null || true"
fi

if [[ "$RM_DOCKER_VOL" == "Y" ]]; then
    ui::subsection "Removing Docker Volumes"
    _rm "All Docker volumes" bash -c "docker volume rm $(docker volume ls -q) 2>/dev/null || true"
    _rm "Pterodactyl data dir" rm -rf /var/lib/pterodactyl/volumes
fi

if [[ "$RM_DOCKER_IMG" == "Y" ]]; then
    ui::subsection "Removing Docker Images"
    _rm "All Docker images" bash -c "docker rmi -f $(docker images -aq) 2>/dev/null || true"
fi

# ==============================================================
# 3 — Remove Wings Service File
# ==============================================================
if [[ "$RM_SERVICE" == "Y" ]]; then
    ui::subsection "Removing Wings Service"
    _rm "Wings service file" rm -f "$WINGS_SERVICE"
    ui::spinner_start "Reloading systemd"
    systemctl daemon-reload 2>/dev/null || true
    ui::spinner_stop "ok" "systemd reloaded"
fi

# ==============================================================
# 4 — Remove Wings Config
# ==============================================================
if [[ "$RM_CONFIG" == "Y" ]]; then
    ui::subsection "Removing Wings Configuration"
    _rm "config.yml" rm -f "${WINGS_DIR}/config.yml"
    # Remove directory only if empty
    rmdir "$WINGS_DIR" 2>/dev/null || true
    ui::status "Wings config directory removed (if empty)" "ok"
fi

# ==============================================================
# 5 — Remove Wings Binary
# ==============================================================
if [[ "$RM_BINARY" == "Y" ]]; then
    ui::subsection "Removing Wings Binary"
    _rm "Wings binary" rm -f "$WINGS_BIN"
fi

# ==============================================================
# 6 — Remove Docker Engine
# ==============================================================
if [[ "$RM_DOCKER" == "Y" ]]; then
    ui::subsection "Removing Docker"
    case "$OS_ID" in
        ubuntu|debian)
            _rm "Docker engine (apt)" bash -c \
                "apt-get purge -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin 2>/dev/null || \
                 apt-get purge -y docker.io 2>/dev/null || true"
            _rm "Docker residual data" bash -c "rm -rf /var/lib/docker /etc/docker"
            ;;
        almalinux|rocky)
            _rm "Docker engine (dnf)" bash -c \
                "dnf remove -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin 2>/dev/null || true"
            _rm "Docker residual data" bash -c "rm -rf /var/lib/docker /etc/docker"
            ;;
    esac
    # Remove docker group socket references
    rm -f /var/run/docker.sock 2>/dev/null || true
    log::ok "Docker removed"
fi

# ==============================================================
# Done
# ==============================================================
echo
ui::divider
echo
ui::ok "${BOLD}Wings has been removed.${RESET}"
log::ok "Wings removal complete."
echo
