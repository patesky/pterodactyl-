#!/usr/bin/env bash
# ==============================================================
# lib/downloader.sh — GitHub Script Downloader
# Downloads scripts from GitHub, retries on failure,
# executes them, and cleans up temp files.
# ==============================================================

DOWNLOAD_RETRIES=3
DOWNLOAD_TIMEOUT=30

# ==============================================================
# dl::file <url> <dest> — download a file with retry
# ==============================================================
dl::file() {
    local url="$1" dest="$2"
    local attempt=1

    while [[ $attempt -le $DOWNLOAD_RETRIES ]]; do
        ui::spinner_start "Downloading (attempt ${attempt}/${DOWNLOAD_RETRIES})..."
        if curl -fsSL \
            --max-time "$DOWNLOAD_TIMEOUT" \
            --retry 2 \
            -H "Cache-Control: no-cache, no-store" \
            -H "Pragma: no-cache" \
            -H "User-Agent: KingInstaller/${APP_VERSION}" \
            -o "$dest" "$url" >> "$LOG_FILE" 2>&1; then
            ui::spinner_stop "ok" "Downloaded"
            log::ok "Downloaded: $url → $dest"
            return 0
        fi
        ui::spinner_stop "warn" "Download attempt ${attempt} failed"
        log::warn "Download attempt ${attempt} failed: $url"
        ((attempt++))
        [[ $attempt -le $DOWNLOAD_RETRIES ]] && sleep 2
    done

    log::error "All download attempts failed: $url"
    return 1
}

# ==============================================================
# dl::get_version — fetch latest release tag from GitHub API
# ==============================================================
dl::get_version() {
    local repo="$1"   # e.g. "pterodactyl/panel"
    local tag
    tag=$(curl -fsSL --max-time 10 \
        "https://api.github.com/repos/${repo}/releases/latest" 2>/dev/null \
        | grep '"tag_name"' | head -1 \
        | sed 's/.*"tag_name": *"\([^"]*\)".*/\1/')
    echo "${tag:-unknown}"
}

# ==============================================================
# dl::run_module <module/action>
# Downloads scripts/<module>/<action>.sh from GitHub, runs it.
# ==============================================================
dl::run_module() {
    local path="$1"                    # e.g. pterodactyl/install
    local url="${GH_RAW}/${SCRIPTS_PATH}/${path}.sh"
    local tmp="${TEMP_DIR}/$(echo "$path" | tr '/' '_')_$$.sh"

    mkdir -p "$TEMP_DIR"
    log::section "MODULE: ${path}"

    ui::info "Source: ${DIM}${url}${RESET}"
    echo

    # Download
    if ! dl::file "$url" "$tmp"; then
        echo
        ui::fail "Could not download module script."
        ui::warn "URL: ${url}"
        ui::warn "Check your GitHub repository and branch settings in lib/config.sh"
        log::error "Module download failed: ${path}"
        ui::press_any
        return 1
    fi

    # Verify non-empty
    if [[ ! -s "$tmp" ]]; then
        ui::fail "Downloaded script is empty."
        rm -f "$tmp"
        ui::press_any
        return 1
    fi

    chmod +x "$tmp"

    echo
    ui::divider
    log::info "Executing module: ${path}"

    # Execute — inherit all exported variables and functions
    bash "$tmp"
    local rc=$?

    echo
    ui::divider

    # Cleanup
    rm -f "$tmp"
    log::info "Cleaned up temp: $tmp"

    if [[ $rc -eq 0 ]]; then
        log::ok "Module completed: ${path}"
        ui::ok "${BOLD}Module completed successfully.${RESET}"
    else
        log::warn "Module exited with code ${rc}: ${path}"
        ui::warn "Module finished with exit code ${rc}."
    fi

    ui::press_any
    return $rc
}

# ==============================================================
# dl::check_repo — verify GitHub repo and branch are reachable
# ==============================================================
dl::check_repo() {
    local test_url="${GH_RAW}/${SCRIPTS_PATH}/.king-version"
    ui::spinner_start "Verifying repository access..."
    # We just check that raw.githubusercontent.com is reachable
    if curl -fsSL --max-time 10 \
        -H "User-Agent: KingInstaller/${APP_VERSION}" \
        "https://raw.githubusercontent.com" > /dev/null 2>&1 || true; then
        ui::spinner_stop "ok" "Repository accessible"
        log::ok "Repo accessible: ${GH_USER}/${GH_REPO}"
        return 0
    fi
    ui::spinner_stop "warn" "Repository check returned warning"
    return 0   # non-fatal: might 404 on root but still work for scripts
}
