#!/usr/bin/env bash
# ==============================================================
# lib/config.sh — King Installer Configuration
# ONLY edit this file to point to your GitHub repository.
# ==============================================================

# ── GitHub Settings ───────────────────────────────────────────
GH_USER="USERNAME"
GH_REPO="REPOSITORY"
GH_BRANCH="main"
GH_RAW="https://raw.githubusercontent.com/${GH_USER}/${GH_REPO}/${GH_BRANCH}"
GH_API="https://api.github.com/repos/${GH_USER}/${GH_REPO}"
SCRIPTS_PATH="scripts"           # Path inside repo: scripts/<module>/<action>.sh

# ── App Info ──────────────────────────────────────────────────
APP_NAME="King Installer"
APP_VERSION="1.0.0"

# ── Local Paths ───────────────────────────────────────────────
LOG_DIR="/var/log/king-installer"
LOG_FILE="${LOG_DIR}/install.log"
TEMP_DIR="/tmp/king-installer"

# ── Pterodactyl Paths ─────────────────────────────────────────
PANEL_DIR="/var/www/pterodactyl"
PANEL_DB="panel"
PANEL_DB_USER="pterodactyl"

# ── Wings Paths ───────────────────────────────────────────────
WINGS_DIR="/etc/pterodactyl"
WINGS_BIN="/usr/local/bin/wings"
WINGS_SERVICE="/etc/systemd/system/wings.service"
