#!/usr/bin/env bash
# ==============================================================
# lib/ui.sh — King Installer Terminal UI Library
# Colors, borders, spinners, progress bars, menus.
# ==============================================================

# ── ANSI Colors ───────────────────────────────────────────────
RESET="\e[0m"
BOLD="\e[1m"
DIM="\e[2m"

BLACK="\e[30m";   BLACK_BG="\e[40m"
RED="\e[31m";     RED_BG="\e[41m"
GREEN="\e[32m";   GREEN_BG="\e[42m"
YELLOW="\e[33m";  YELLOW_BG="\e[43m"
BLUE="\e[34m";    BLUE_BG="\e[44m"
MAGENTA="\e[35m"; MAGENTA_BG="\e[45m"
CYAN="\e[36m";    CYAN_BG="\e[46m"
WHITE="\e[37m";   WHITE_BG="\e[47m"

BRIGHT_RED="\e[91m"
BRIGHT_GREEN="\e[92m"
BRIGHT_YELLOW="\e[93m"
BRIGHT_BLUE="\e[94m"
BRIGHT_MAGENTA="\e[95m"
BRIGHT_CYAN="\e[96m"
BRIGHT_WHITE="\e[97m"

# ── Symbols ───────────────────────────────────────────────────
SYM_OK="✓"
SYM_FAIL="✗"
SYM_WARN="⚠"
SYM_INFO="●"
SYM_ARROW="›"
SYM_BULLET="•"
SYM_GEAR="⚙"
SYM_STAR="★"

# ── Terminal Width ─────────────────────────────────────────────
TERM_WIDTH=$(tput cols 2>/dev/null || echo 70)
[[ $TERM_WIDTH -lt 50 ]] && TERM_WIDTH=70
[[ $TERM_WIDTH -gt 100 ]] && TERM_WIDTH=100
INNER_W=$((TERM_WIDTH - 4))

# ── Spinner State ─────────────────────────────────────────────
_SPINNER_PID=""

# ==============================================================
# ui::clear — clear terminal
# ==============================================================
ui::clear() { clear; }

# ==============================================================
# ui::repeat <char> <count> — repeat a character N times
# ==============================================================
ui::repeat() {
    local char="$1" count="$2" i
    for ((i=0; i<count; i++)); do printf "%s" "$char"; done
}

# ==============================================================
# ui::center <text> [width] — center text within width
# ==============================================================
ui::center() {
    local text="$1"
    local width="${2:-$TERM_WIDTH}"
    # Strip ANSI for length calculation
    local plain; plain=$(echo -e "$text" | sed 's/\x1B\[[0-9;]*m//g')
    local len=${#plain}
    local pad=$(( (width - len) / 2 ))
    [[ $pad -lt 0 ]] && pad=0
    printf "%${pad}s%b\n" "" "$text"
}

# ==============================================================
# ui::banner — top-of-screen application banner
# ==============================================================
ui::banner() {
    local w=$TERM_WIDTH
    echo
    echo -e "${CYAN}$(ui::repeat '═' $w)${RESET}"
    ui::center "${BOLD}${BRIGHT_YELLOW}${SYM_STAR}  KING INSTALLER  ${SYM_STAR}${RESET}"
    ui::center "${DIM}${CYAN}GitHub Script Manager  •  v${APP_VERSION}${RESET}"
    echo -e "${CYAN}$(ui::repeat '═' $w)${RESET}"
    # Info bar
    local now; now=$(date '+%Y-%m-%d %H:%M:%S')
    echo -e "  ${DIM}${CYAN}Date: ${now}   Branch: ${GH_BRANCH}   Repo: ${GH_USER}/${GH_REPO}${RESET}"
    echo -e "${DIM}${CYAN}$(ui::repeat '─' $w)${RESET}"
    echo
}

# ==============================================================
# ui::section <TITLE> — section header box
# ==============================================================
ui::section() {
    local title="$1"
    local w=$TERM_WIDTH
    echo
    echo -e "${CYAN}$(ui::repeat '═' $w)${RESET}"
    ui::center "${BOLD}${BRIGHT_YELLOW}${title}${RESET}"
    echo -e "${CYAN}$(ui::repeat '═' $w)${RESET}"
    echo
}

# ==============================================================
# ui::subsection <TITLE> — lighter sub-section divider
# ==============================================================
ui::subsection() {
    local title="$1"
    local w=$TERM_WIDTH
    echo
    echo -e "${DIM}${CYAN}$(ui::repeat '─' $w)${RESET}"
    echo -e "  ${BOLD}${BRIGHT_CYAN}${title}${RESET}"
    echo -e "${DIM}${CYAN}$(ui::repeat '─' $w)${RESET}"
    echo
}

# ==============================================================
# ui::divider — horizontal rule
# ==============================================================
ui::divider() {
    echo -e "${DIM}${CYAN}$(ui::repeat '─' $TERM_WIDTH)${RESET}"
}

# ==============================================================
# Logging-style message printers
# ==============================================================
ui::ok()      { echo -e "  ${BRIGHT_GREEN}${SYM_OK}${RESET}  $*"; }
ui::fail()    { echo -e "  ${BRIGHT_RED}${SYM_FAIL}${RESET}  $*"; }
ui::warn()    { echo -e "  ${BRIGHT_YELLOW}${SYM_WARN}${RESET}  $*"; }
ui::info()    { echo -e "  ${BRIGHT_CYAN}${SYM_INFO}${RESET}  $*"; }
ui::step()    { echo -e "  ${BRIGHT_MAGENTA}${SYM_GEAR}${RESET}  ${BOLD}$*${RESET}"; }
ui::bullet()  { echo -e "    ${DIM}${CYAN}${SYM_BULLET}${RESET}  $*"; }
ui::arrow()   { echo -e "  ${YELLOW}${SYM_ARROW}${RESET}  $*"; }

# ==============================================================
# ui::status <label> <ok|fail|skip> — two-column status line
# ==============================================================
ui::status() {
    local label="$1" state="$2"
    local w=$((INNER_W - 10))
    printf "  %-${w}s" "$label"
    case "$state" in
        ok)   echo -e "  [ ${BRIGHT_GREEN}${SYM_OK} OK${RESET}     ]" ;;
        fail) echo -e "  [ ${BRIGHT_RED}${SYM_FAIL} FAIL${RESET}   ]" ;;
        skip) echo -e "  [ ${DIM}SKIP${RESET}    ]" ;;
        warn) echo -e "  [ ${BRIGHT_YELLOW}${SYM_WARN} WARN${RESET}   ]" ;;
        *)    echo -e "  [ ${DIM}${state}${RESET} ]" ;;
    esac
}

# ==============================================================
# ui::check_item <label> <ok|fail|skip> — dependency check row
# ==============================================================
ui::check_item() {
    local label="$1" state="$2"
    case "$state" in
        ok)   echo -e "    ${BRIGHT_GREEN}${SYM_OK}${RESET}  ${label}" ;;
        fail) echo -e "    ${BRIGHT_RED}${SYM_FAIL}${RESET}  ${label}  ${DIM}(will install)${RESET}" ;;
        skip) echo -e "    ${DIM}─  ${label} (skipped)${RESET}" ;;
    esac
}

# ==============================================================
# ui::progress_bar <current> <total> [label]
# ==============================================================
ui::progress_bar() {
    local current="$1" total="$2" label="${3:-}"
    local bar_width=40
    [[ $total -le 0 ]] && total=1
    local pct=$(( current * 100 / total ))
    local filled=$(( current * bar_width / total ))
    local empty=$(( bar_width - filled ))

    local bar=""
    bar+="${BRIGHT_GREEN}"
    bar+="$(ui::repeat '█' $filled)"
    bar+="${DIM}${CYAN}"
    bar+="$(ui::repeat '░' $empty)"
    bar+="${RESET}"

    printf "\r  ${CYAN}[${RESET}%b${CYAN}]${RESET} ${BRIGHT_YELLOW}%3d%%${RESET}  ${DIM}%s${RESET}  " \
        "$bar" "$pct" "$label"

    [[ $current -ge $total ]] && echo
}

# ==============================================================
# ui::spinner_start <message> — start background spinner
# ==============================================================
ui::spinner_start() {
    local msg="${1:-Working...}"
    local frames=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏')
    (
        local i=0
        while true; do
            printf "\r  ${BRIGHT_CYAN}%s${RESET}  %b" \
                "${frames[i % ${#frames[@]}]}" "${CYAN}${msg}${RESET}"
            sleep 0.08
            ((i++))
        done
    ) &
    _SPINNER_PID=$!
    disown "$_SPINNER_PID" 2>/dev/null
}

# ==============================================================
# ui::spinner_stop [ok|fail] <message>
# ==============================================================
ui::spinner_stop() {
    local state="${1:-ok}" msg="$2"
    [[ -n "$_SPINNER_PID" ]] && kill "$_SPINNER_PID" 2>/dev/null
    _SPINNER_PID=""
    printf "\r%${TERM_WIDTH}s\r" ""   # clear line
    [[ -n "$msg" ]] && ui::status "$msg" "$state"
}

# ==============================================================
# ui::menu_item <key> <label> — styled menu row
# ==============================================================
ui::menu_item() {
    local key="$1" label="$2"
    echo -e "    ${DIM}${CYAN}[${RESET}${BOLD}${BRIGHT_YELLOW}${key}${RESET}${DIM}${CYAN}]${RESET}  ${BRIGHT_WHITE}${label}${RESET}"
}

# ==============================================================
# ui::menu_exit <label> — [0] back/exit row
# ==============================================================
ui::menu_exit() {
    local label="${1:-Exit}"
    echo
    echo -e "    ${DIM}${CYAN}[${RESET}${RED}0${RESET}${DIM}${CYAN}]${RESET}  ${DIM}${label}${RESET}"
}

# ==============================================================
# ui::prompt <variable> <prompt_text> [default]
# ==============================================================
ui::prompt() {
    local _varname="$1"
    local _prompt="$2"
    local _default="${3:-}"
    local _input

    if [[ -n "$_default" ]]; then
        echo -ne "\n  ${BRIGHT_YELLOW}${SYM_ARROW}${RESET}  ${_prompt} ${DIM}[${_default}]${RESET}: "
    else
        echo -ne "\n  ${BRIGHT_YELLOW}${SYM_ARROW}${RESET}  ${_prompt}: "
    fi

    read -r _input
    [[ -z "$_input" && -n "$_default" ]] && _input="$_default"
    printf -v "$_varname" '%s' "$_input"
}

# ==============================================================
# ui::prompt_secret <variable> <prompt_text>
# ==============================================================
ui::prompt_secret() {
    local _varname="$1" _prompt="$2" _input
    echo -ne "\n  ${BRIGHT_YELLOW}${SYM_ARROW}${RESET}  ${_prompt}: "
    read -rs _input
    echo
    printf -v "$_varname" '%s' "$_input"
}

# ==============================================================
# ui::prompt_yn <variable> <prompt_text> [Y|N]
# ==============================================================
ui::prompt_yn() {
    local _varname="$1" _prompt="$2" _default="${3:-Y}" _input
    local _opts; [[ "$_default" == "Y" ]] && _opts="${BRIGHT_GREEN}Y${RESET}/${DIM}n${RESET}" || _opts="${DIM}y${RESET}/${BRIGHT_RED}N${RESET}"
    echo -ne "\n  ${BRIGHT_YELLOW}${SYM_ARROW}${RESET}  ${_prompt} [${_opts}]: "
    read -r _input
    [[ -z "$_input" ]] && _input="$_default"
    printf -v "$_varname" '%s' "${_input^^}"
}

# ==============================================================
# ui::confirm_word <word> — require typing a specific word
# ==============================================================
ui::confirm_word() {
    local required="$1" _input
    echo -e "\n  ${BRIGHT_RED}${BOLD}This action is irreversible.${RESET}"
    echo -ne "  Type ${BOLD}${BRIGHT_RED}${required}${RESET} to confirm: "
    read -r _input
    [[ "$_input" == "$required" ]]
}

# ==============================================================
# ui::summary_row <label> <value> — two-column summary table row
# ==============================================================
ui::summary_row() {
    local label="$1" value="$2"
    printf "    ${DIM}${CYAN}%-28s${RESET}  ${BRIGHT_WHITE}%s${RESET}\n" "${label}:" "${value}"
}

# ==============================================================
# ui::pause — press Enter to continue
# ==============================================================
ui::pause() {
    echo
    echo -e "  ${DIM}Press ${BRIGHT_WHITE}Enter${RESET}${DIM} to continue...${RESET}"
    read -r
}

# ==============================================================
# ui::press_any — press any key to return
# ==============================================================
ui::press_any() {
    echo
    ui::divider
    echo -e "  ${DIM}Press any key to return to the menu...${RESET}"
    read -rsn1
}

# ==============================================================
# ui::menu_choice <variable> — styled choice prompt
# ==============================================================
ui::menu_choice() {
    local _varname="$1"
    local _input
    echo
    echo -ne "  ${BRIGHT_YELLOW}${BOLD}${SYM_ARROW}${RESET}  Enter choice: "
    read -r _input
    printf -v "$_varname" '%s' "$_input"
}
