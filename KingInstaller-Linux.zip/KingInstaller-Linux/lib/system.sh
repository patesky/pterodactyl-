#!/usr/bin/env bash
# ==============================================================
# lib/system.sh — OS Detection, Root Check, Internet Check,
#                 Dependency Management
# ==============================================================

# ── OS Detection ──────────────────────────────────────────────
# Sets: OS_NAME  OS_VERSION  OS_ID  PKG_MANAGER  PKG_UPDATE
#       PKG_INSTALL  PKG_QUERY  SUPPORTED=true|false
sys::detect_os() {
    if [[ -f /etc/os-release ]]; then
        source /etc/os-release
        OS_NAME="$NAME"
        OS_VERSION="$VERSION_ID"
        OS_ID="${ID,,}"
        OS_ID_LIKE="${ID_LIKE,,}"
    else
        OS_NAME="Unknown"
        OS_VERSION="0"
        OS_ID="unknown"
        OS_ID_LIKE=""
    fi

    SUPPORTED=false

    case "$OS_ID" in
        ubuntu)
            PKG_MANAGER="apt"
            PKG_UPDATE="apt-get update -qq"
            PKG_INSTALL="apt-get install -y -qq"
            PKG_QUERY="dpkg -s"
            case "${OS_VERSION%%.*}" in
                22|24) SUPPORTED=true ;;
            esac
            ;;
        debian)
            PKG_MANAGER="apt"
            PKG_UPDATE="apt-get update -qq"
            PKG_INSTALL="apt-get install -y -qq"
            PKG_QUERY="dpkg -s"
            case "${OS_VERSION%%.*}" in
                11|12) SUPPORTED=true ;;
            esac
            ;;
        almalinux|alma)
            OS_ID="almalinux"
            PKG_MANAGER="dnf"
            PKG_UPDATE="dnf makecache -q"
            PKG_INSTALL="dnf install -y -q"
            PKG_QUERY="rpm -q"
            case "${OS_VERSION%%.*}" in
                9) SUPPORTED=true ;;
            esac
            ;;
        rocky)
            PKG_MANAGER="dnf"
            PKG_UPDATE="dnf makecache -q"
            PKG_INSTALL="dnf install -y -q"
            PKG_QUERY="rpm -q"
            case "${OS_VERSION%%.*}" in
                9) SUPPORTED=true ;;
            esac
            ;;
        *)
            # Fallback: try to detect via ID_LIKE
            if [[ "$OS_ID_LIKE" == *"debian"* || "$OS_ID_LIKE" == *"ubuntu"* ]]; then
                PKG_MANAGER="apt"
                PKG_UPDATE="apt-get update -qq"
                PKG_INSTALL="apt-get install -y -qq"
                PKG_QUERY="dpkg -s"
                SUPPORTED=true
            elif [[ "$OS_ID_LIKE" == *"rhel"* || "$OS_ID_LIKE" == *"fedora"* ]]; then
                PKG_MANAGER="dnf"
                PKG_UPDATE="dnf makecache -q"
                PKG_INSTALL="dnf install -y -q"
                PKG_QUERY="rpm -q"
                SUPPORTED=true
            fi
            ;;
    esac
}

# ── Root Privilege Check ───────────────────────────────────────
sys::require_root() {
    if [[ $EUID -ne 0 ]]; then
        echo
        ui::fail "This installer must be run as ${BOLD}root${RESET}."
        ui::info "Run: ${BRIGHT_YELLOW}sudo bash king-installer.sh${RESET}"
        echo
        exit 1
    fi
}

# ── Internet & GitHub Connectivity ────────────────────────────
sys::check_internet() {
    ui::step "Checking connectivity..."
    echo

    ui::spinner_start "Testing internet access..."
    if curl -sf --max-time 5 "https://www.google.com" > /dev/null 2>&1; then
        ui::spinner_stop "ok" "Internet connection"
        log::ok "Internet: reachable"
    else
        ui::spinner_stop "fail" "Internet connection"
        log::error "Internet: unreachable"
        ui::fail "No internet connection. Please check your network."
        return 1
    fi

    ui::spinner_start "Testing GitHub access..."
    if curl -sf --max-time 8 "https://github.com" > /dev/null 2>&1; then
        ui::spinner_stop "ok" "GitHub reachable"
        log::ok "GitHub: reachable"
    else
        ui::spinner_stop "fail" "GitHub reachable"
        log::error "GitHub: unreachable"
        ui::fail "Cannot reach GitHub. Check DNS or try again later."
        return 1
    fi

    echo
    return 0
}

# ── OS Support Check ──────────────────────────────────────────
sys::check_os() {
    if [[ "$SUPPORTED" != "true" ]]; then
        ui::warn "OS ${BOLD}${OS_NAME} ${OS_VERSION}${RESET} is not officially supported."
        ui::warn "Supported: Ubuntu 22/24, Debian 11/12, AlmaLinux 9, Rocky Linux 9"
        echo
        ui::prompt_yn _CONTINUE "Continue anyway?" "N"
        [[ "${_CONTINUE}" != "Y" ]] && return 1
    fi
    return 0
}

# ── Package Installed Check ────────────────────────────────────
# Returns 0 if installed, 1 if not
sys::pkg_installed() {
    local pkg="$1"
    $PKG_QUERY "$pkg" > /dev/null 2>&1
}

# ── Command Exists Check ───────────────────────────────────────
sys::cmd_exists() {
    command -v "$1" > /dev/null 2>&1
}

# ── Install a Package ─────────────────────────────────────────
sys::install_pkg() {
    local pkg="$1" label="${2:-$1}"
    ui::spinner_start "Installing ${label}..."
    if $PKG_INSTALL "$pkg" >> "$LOG_FILE" 2>&1; then
        ui::spinner_stop "ok" "Installed ${label}"
        log::ok "Installed: $pkg"
        return 0
    else
        ui::spinner_stop "fail" "Failed to install ${label}"
        log::error "Failed to install: $pkg"
        return 1
    fi
}

# ── Update Package Index ───────────────────────────────────────
sys::pkg_update() {
    ui::spinner_start "Updating package index..."
    if $PKG_UPDATE >> "$LOG_FILE" 2>&1; then
        ui::spinner_stop "ok" "Package index updated"
        log::ok "Package index updated"
    else
        ui::spinner_stop "warn" "Package index update had warnings"
        log::warn "Package update had warnings — continuing"
    fi
}

# ── Detect Installed PHP Version ──────────────────────────────
sys::detect_php() {
    PHP_VERSION=""
    for v in 8.3 8.2 8.1 8.0; do
        if sys::cmd_exists "php${v}"; then
            PHP_VERSION="$v"
            break
        fi
    done
    if sys::cmd_exists php && [[ -z "$PHP_VERSION" ]]; then
        PHP_VERSION=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || echo "")
    fi
}

# ── Generate Random Password ───────────────────────────────────
sys::gen_password() {
    local len="${1:-24}"
    tr -dc 'A-Za-z0-9!@#%^&*' < /dev/urandom | head -c "$len"
    echo
}

# ── Print OS Info Row ─────────────────────────────────────────
sys::print_os_info() {
    echo
    ui::summary_row "Operating System" "${OS_NAME} ${OS_VERSION}"
    ui::summary_row "Package Manager"  "${PKG_MANAGER}"
    ui::summary_row "Architecture"     "$(uname -m)"
    ui::summary_row "Kernel"           "$(uname -r)"
    [[ "$SUPPORTED" == "true" ]] \
        && ui::summary_row "Support Status" "${BRIGHT_GREEN}Supported${RESET}" \
        || ui::summary_row "Support Status" "${BRIGHT_YELLOW}Unsupported (continued)${RESET}"
    echo
}
