#!/usr/bin/env bash
# ==============================================================
# lib/logger.sh — King Installer Logger
# Writes timestamped, levelled entries to the log file.
# ==============================================================

# Ensure log directory exists (called once at startup)
logger::init() {
    mkdir -p "$LOG_DIR" || true
    touch "$LOG_FILE"   || true
    log::info "========================================"
    log::info "SESSION START  ${APP_NAME} v${APP_VERSION}"
    log::info "Repo: ${GH_USER}/${GH_REPO} [${GH_BRANCH}]"
    log::info "OS:   ${OS_NAME:-unknown} ${OS_VERSION:-}"
    log::info "========================================"
}

# Internal write
_log() {
    local level="$1"; shift
    local ts; ts=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$ts] [$level] $*" >> "$LOG_FILE"
}

log::info()    { _log "INFO " "$@"; }
log::ok()      { _log "OK   " "$@"; }
log::warn()    { _log "WARN " "$@"; }
log::error()   { _log "ERROR" "$@"; }
log::section() { _log "----" "--- $* ---"; }

# Run a command, log stdout+stderr, show spinner
# Usage: logger::run <label> <cmd> [args...]
logger::run() {
    local label="$1"; shift
    log::info "RUN: $*"
    ui::spinner_start "$label"
    local out
    out=$("$@" 2>&1)
    local rc=$?
    ui::spinner_stop
    if [[ $rc -eq 0 ]]; then
        log::ok "$label — exit 0"
        ui::status "$label" "ok"
    else
        log::error "$label — exit $rc"
        log::error "OUTPUT: $out"
        ui::status "$label" "fail"
    fi
    return $rc
}

# Run silently (no spinner), log everything
logger::run_quiet() {
    local label="$1"; shift
    log::info "RUN(quiet): $*"
    local out
    out=$("$@" 2>&1)
    local rc=$?
    if [[ $rc -eq 0 ]]; then
        log::ok "$label — exit 0"
    else
        log::error "$label — exit $rc"
        log::error "OUTPUT: $out"
    fi
    return $rc
}
